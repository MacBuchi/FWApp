# Änderungen

Alle nennenswerten Änderungen an FWApp, neueste zuerst.

Die Einträge sind bewusst so formuliert, dass sie auch in der App unter
**Einstellungen → Was ist neu?** verständlich sind — also aus Sicht der
Anwenderin, nicht aus Sicht des Codes. Das Format orientiert sich an
[Keep a Changelog](https://keepachangelog.com/de/1.1.0/), die Versionen an
[Semantic Versioning](https://semver.org/lang/de/).

Diese Datei wird als Asset mitgeliefert und in der App gerendert. Wer sie
ändert, ändert damit auch den Text auf den Geräten — siehe AGENTS.md,
Abschnitt „Workflow".

## [1.63.0] – 2026-09-23

### Neu

- **Neue Handys per QR-Code verbinden.** Unter **Einstellungen → Weiteres
  Gerät verbinden** zeigt die App einen Einrichtungs-Code. Wer die App neu
  installiert, tippt auf der Anmeldeseite auf **„Mit anderem Server
  verbinden"**, scannt den Code — und die App spricht mit dem Server der
  eigenen Wehr. Kein Abtippen von Adresse und Schlüssel mehr. Den Code darf
  jedes Mitglied zeigen: Er verbindet nur mit dem Server, anmelden kann sich
  danach trotzdem nur, wer einen Zugang hat.

- **Oder einfach die Adresse der Wehr eintippen.** Statt des Codes geht
  auch die Domain, etwa `feuerwehr-musterstadt.de` — den Rest holt sich die
  App von dort. Vor dem Umstellen prüft sie, ob der Server wirklich
  antwortet; danach startet sie neu (im Browser lädt die Seite neu, auf dem
  Handy bittet die App darum, sie einmal zu schließen und neu zu öffnen).

- **Die Web-App findet ihren Server selbst**, wenn sie vom Server einer
  Wehr ausgeliefert wird. Das ist die Grundlage dafür, dass eine Feuerwehr
  künftig ihren eigenen Server betreiben kann, ohne eine eigene App zu
  bauen. Für die bestehende Installation ändert sich nichts.

## [1.62.0] – 2026-09-23

### Neu

- **Eine neue Feuerwehr weiß, an wen sie sich wenden kann.** Auf der
  Anmeldeseite steht jetzt „Deine Wehr ist noch nicht dabei?" mit der
  Kontaktadresse des Betreibers — sofern er eine hinterlegt hat. Eine
  Selbstanmeldung gibt es weiterhin nicht: Neue Wehren richtet der
  Betreiber ein.

- **Konsole für den Betreiber der Installation („KreisDatenMeister").** Wer
  den Server betreibt, findet unter **Einstellungen → KreisDatenMeister**
  alle Feuerwehren auf einen Blick: Abteilungen, Mitglieder, Kommandanten,
  offene Einladungen und wann zuletzt veröffentlicht wurde. Von dort legt er
  eine neue Wehr samt erster Abteilung an und lädt ihren
  Feuerwehrkommandanten per Mail ein. Die Konsole warnt, wenn eine Wehr gar
  keinen oder nur einen Kommandanten hat — fällt der aus, kann dort sonst
  niemand mehr einladen. Für diesen Fall kann der Betreiber einen
  Kommandanten hinzufügen: Hat die Person schon ein Konto, sofort, sonst per
  Einladung. Alle anderen sehen den Eintrag nicht.

- **Eine Feuerwehr kann stillgelegt werden** — etwa eine Probe-Wehr oder
  eine, die die App nicht mehr nutzt. Dann sind Veröffentlichen, Einladen und
  das Einreichen von Wissensfragen gesperrt; Nachschlagen und Lernen gehen
  weiter, und **auf den Handys wird nichts gelöscht**. Wer betroffen ist,
  sieht das auf der Startseite, samt Kontakt. Der Betreiber kann die Wehr
  jederzeit wieder aktivieren.

## [1.61.0] – 2026-09-23

### Neu

- **Lerngruppen haben jetzt eine Wochenaufgabe und eine Rangliste.** Jede
  Woche (Montag bis Sonntag) ist ein Lernmodus dran — Fach-Quiz,
  Bild-Erkennung, „Wo liegt's?" oder Drag & Drop, reihum. In der Gruppe
  steht, welcher es diese Woche ist, mit einem Knopf „Jetzt spielen".

  Gewertet wird der **Schnitt deiner letzten zwei Runden** der Woche in
  diesem Modus, als Trefferquote in Prozent. Wer sich verbessert, steigt;
  eine einzelne Glücksrunde allein reicht nicht, und wie lange jemand spielt,
  zählt gar nicht. Weil jeder am Bestand seiner eigenen Abteilung spielt,
  zählt die Quote und nicht die Zahl der Treffer.

  Die Rangliste zeigt die laufende Woche und eine **Gesamtwertung** (die
  Summe der Wochenwerte — jede Woche, in der du dabei warst, zählt).
  Solange eine Gruppe läuft, steht auf der Startseite eine Karte mit der
  Wochenaufgabe und deinem Platz.

  **Was dafür geteilt wird — und was nicht:** Zum ersten Mal verlässt ein
  Lernergebnis dein Handy. Es ist genau **eine Zahl pro Woche**: dein Wert
  im Modus der Wochenaufgabe. Nicht, welche Fragen du falsch hattest, nicht,
  welche Geräte du nicht kennst, nicht, wie oft du gespielt hast, und nichts
  aus den anderen Modi. Sehen können diese Zahl nur die Mitglieder deiner
  Gruppe. Wer die Gruppe verlässt, nimmt seine Werte mit. Die Karteikarten
  sind nie Wochenaufgabe, weil man dort selbst einschätzt, ob man es wusste.

### Geändert

- **Lerngruppen enden immer an einem Sonntag.** „8 Wochen" heißt jetzt acht
  Kalenderwochen, die angefangene Woche der Gründung mitgezählt — sonst
  hätte die letzte Woche mitten im Dienstrhythmus aufgehört.

## [1.60.0] – 2026-09-23

### Neu

- **Lerngruppen.** Unter **Lernen → Lerngruppen** kannst du dich mit ein paar
  Leuten aus deiner Gesamtwehr für eine Weile zusammentun — vier bis zwölf
  Wochen, voreingestellt acht. Wer die Gruppe gründet, bekommt einen
  **sechsstelligen Code**. Den gibst du weiter (vorlesen, in den Gruppenchat
  schicken), und wer ihn unter „Mit Code beitreten" eintippt, ist dabei.

  In der Gruppe siehst du, wer mitmacht und wie lange sie noch läuft.
  Beendete Gruppen bleiben gedämpft in der Liste stehen, damit du siehst, wer
  dabei war; verlassen kannst du eine Gruppe jederzeit.

  Das ist der erste Teil. **Wochenaufgabe und Rangliste kommen mit einem der
  nächsten Updates** — und dann gilt, was schon feststeht: Zum Server geht
  nur eine Punktzahl je Lernmodus, nie, welche Frage du falsch hattest.

  Lerngruppen brauchen eine Anmeldung und eine Gesamtwehr. Alles andere in
  der App funktioniert weiterhin auch ohne Netz.

## [1.59.0] – 2026-09-22

### Neu

- **Vor dem Veröffentlichen fragt die App, ob etwas zweimal dasselbe ist.**
  Wenn zwei Gerätewarte gemeinsam erfassen, stehen danach beide Erfassungen
  nebeneinander — so soll es sein. Haben aber beide dasselbe Strahlrohr
  gemeint und nur verschieden geschrieben, stünde es nach dem
  Veröffentlichen zweimal im Bestand der Wehr, und das fällt erst Wochen
  später bei der Inventur auf.

  Jetzt sieht die App vorher nach und fragt, in zwei Gruppen: zuerst, was im
  **selben Geräteraum desselben Fahrzeugs** ähnlich heißt — das ist fast
  immer ein Gerät, das zwei Leute erfasst haben. Danach, deutlich
  zurückhaltender, **ähnliche Namen im ganzen Bestand**: Ein Gerätetyp gehört
  der ganzen Wehr, und zwei Einträge dafür verschmutzen den Katalog
  dauerhaft.

  Du entscheidest je Paar, und bei „dasselbe" auch, welcher Name bleibt.
  Beladung, Geräte-Einheiten und aufgeklebte Codes ziehen mit um; liegen
  beide im selben Fach, werden die Stückzahlen addiert — jeder hatte seinen
  Teil gezählt.

  ⚠️ Voreingestellt ist **„verschieden"**. Wer den Dialog nur bestätigt,
  verliert nichts: Zusammengeführt wird ausschließlich, was du dafür
  auswählst. Gefragt wird außerdem nur zu Geräten, die auf diesem Gerät neu
  entstanden sind — gewachsene Bestandsdaten bleiben unangetastet.

## [1.58.1] – 2026-09-22

### Geändert

- **Innere Aufräumarbeit: einheitliche Code-Formatierung.** An der App
  ändert sich nichts — kein Bildschirm, kein Ablauf, keine Zahl. Der
  Quelltext war von Hand umbrochen und ist jetzt einmal durch das
  Standardwerkzeug gelaufen; die Prüfung dafür läuft ab sofort bei jeder
  Änderung automatisch mit, damit es so bleibt.

## [1.58.0] – 2026-09-22

### Geändert

- **Zusammen erfassen, ohne sich gegenseitig zu löschen.** Wenn zwei
  Gerätewarte am selben Fahrzeug arbeiten — einer am Geräteraum G1, der
  andere am Heck — hat der Zweite seine Arbeit bisher verloren: Wer als
  Zweiter veröffentlichen wollte, bekam einen Versionskonflikt, und wer
  vorher zog, dessen eigene Einträge waren weg. Ein Ausweg aus dieser
  Sackgasse fehlte (Issue #67).

  Jetzt merkt sich die App pro Zeile, was hier entstanden und noch nicht
  veröffentlicht ist. Ein Zug bringt den Stand der Wehr, **ohne** diese
  Zeilen anzufassen — danach steht beides nebeneinander da und kann
  gemeinsam veröffentlicht werden. Vergeben zwei Geräte zufällig dieselbe
  laufende Nummer, bekommt die eigene, noch nicht veröffentlichte Zeile eine
  freie — mitsamt allem, was daran hängt (Prüftermine, Geräte-Codes).

  Was jemand anders gelöscht hat, verschwindet weiterhin; die Rückfrage vor
  dem Zug (seit 1.55.0) fragt jetzt nur noch dann, wenn wirklich etwas
  wegfällt, statt bei jedem Zug.

  ⚠️ Der mitgelieferte Grundstock — Standard-Katalog und Demo-HLF — gilt
  ausdrücklich **nicht** als eigene Erfassung und wird vom ersten Zug nach
  dem Beitritt ersetzt wie bisher. Er gehört der App, nicht der Abteilung.

## [1.57.0] – 2026-09-22

### Geändert

- **Neue Startanimation: das Fach geht auf, statt dass es brennt.** Die
  bisherige zeigte Flamme, Löschen, Logo — also den Einsatz. Diese App ist
  aber die Zeit davor: beladen, lernen, prüfen, damit im Einsatz alles da
  ist. Jetzt fährt ein Rollladen hoch, das Fach steht offen, es bekommt
  seinen Haken, und daraus wird das Zeichen der App.

  Länge und Verhalten bleiben: 4,3 Sekunden nach Installation und Update,
  sonst die Kurzform, Antippen bricht ab, und die App baut die ganze Zeit
  darunter weiter.

- **Der Anmeldebildschirm trägt jetzt dieselbe Marke wie das App-Icon.**
  Dort stand noch die alte Flamme. Als Symbol für *Einsatz* und für die
  Lern-Serie bleibt sie, wo sie hingehört — als Marke nicht mehr.

## [1.56.0] – 2026-09-22

### Geändert

- **Neues App-Icon: Feuerwehrhelm mit Prüf-Abzeichen.** Das bisherige —
  weiße Flamme auf rotem Verlauf — war von der Tinder-Marke kaum zu
  unterscheiden, und es sagte nichts darüber, dass diese App zum Lernen und
  Verwalten da ist.

  Der Helm sagt, um wen es geht; der Haken sagt, worum: geprüft und gewusst.
  Flach statt Verlauf, damit das Icon überall gleich aussieht — auch dort,
  wo Android seinen eigenen Hintergrund malt.

  Das Startbild trägt noch die alte Flamme; das kommt als eigener Schritt.

## [1.55.0] – 2026-09-22

### Neu

- **Der Inventurbericht sagt jetzt, WONACH zu suchen ist.** Bisher stand da
  „2 von 4" — und der Gerätewart zählte das Fach noch einmal durch, um
  herauszufinden, welche zwei fehlen. Die neue Spalte „Nicht gefunden"
  benennt sie: „Flasche 3 (FW-7K2M9Q), Flasche 7".

  **Sie bleibt leer, wo die App es nicht weiß.** Welche Einheit gezählt
  wurde, weiß sie nur beim Abhaken per Code. Wer die Stückzahl von Hand
  setzt, sagt ihr nur, WIE VIELE da waren — dann steht dort nichts, statt
  zu raten. Eine Liste, die jemanden nach Dingen suchen lässt, die im Fach
  liegen, wäre schlimmer als keine.

## [1.54.2] – 2026-09-22

### Behoben

- **Auch der Abteilungswechsel fragt jetzt, bevor er etwas löscht.** Der
  Wechsel lädt den Bestand der neuen Sicht — und ersetzte dabei, was dort
  noch nicht veröffentlicht war. Das traf vor allem den Weg **zurück in die
  eigene Abteilung**: Wer dort etwas angelegt, dann kurz zur
  Schwester-Abteilung geschaut hatte, verlor es beim Zurückkommen.

  Jetzt kommt dieselbe Frage wie beim Aktualisieren, und sie nennt die
  Zahlen. Wer abbricht, bleibt in der neuen Sicht, und die App sagt es:
  „Gewechselt, aber nichts geladen — was hier noch nicht veröffentlicht
  ist, bleibt stehen."

## [1.54.1] – 2026-09-22

### Behoben

- **„Jetzt aktualisieren" löschte unveröffentlichte Arbeit ohne zu fragen.**
  Wer ein Fahrzeug, ein Fach oder eine Geräte-Einheit angelegt und noch
  nicht veröffentlicht hatte, verlor es beim nächsten Aktualisieren — ohne
  Hinweis, ohne Nachfrage.

  Jetzt fragt die App vorher, und sie sagt, worum es geht: „Auf dem Server
  fehlt, was hier angelegt wurde: 1 Fahrzeug." Abbrechen behält alles;
  veröffentlichen und danach aktualisieren ebenso.

  **Gefragt wird nur, wenn wirklich etwas verschwände.** Beim gewöhnlichen
  Aktualisieren kommt nichts dazwischen — eine Rückfrage, die immer kommt,
  liest nach dem dritten Mal niemand mehr.

## [1.54.0] – 2026-09-22

### Neu

- **Code scannen und die Suche sagt, wo das Gerät hingehört.** In der
  Gerätesuche liegt oben rechts jetzt ein Scanner. Der Fall dahinter kennt
  jeder: Ein Strahlrohr liegt im falschen Fach, und niemand weiß auf Anhieb,
  in welches es gehört. Kamera drauf — und da steht Fahrzeug, Fach und
  Seite.

  Der Code lässt sich genauso eintippen, in jeder Schreibweise; ein
  Handscanner tippt ohnehin ins selbe Feld. Wo NFC da ist, geht es auch
  damit.

  Ein Code zeigt dabei auf **genau einen** Gegenstand, nicht auf eine
  Auswahl: Liegen Strahlrohre in zwei Fächern, nennt die App das Fach der
  Einheit, auf der der Aufkleber klebt — nicht beide.

  Und wer am falschen Fahrzeug steht, bekommt trotzdem die Antwort: „nicht
  hier, aber im HLF 20, Fach G1".

## [1.53.1] – 2026-09-22

### Behoben

- **Nach dem Wechsel auf eine Schwester-Abteilung fehlten deren Codes und
  Unterlagen.** Die Fahrzeuge und Geräte kamen, die Codes nicht — wer dort
  eine Inventur öffnete und scannte, bekam „klebt auf keinem erfassten
  Gerät", und nichts sagte einem, dass ein „Jetzt aktualisieren" gefehlt
  hätte. Dasselbe galt für die Unterlagen am Fahrzeug, und das schon seit
  es sie gibt.

  Der Wechsel holt jetzt alles mit, wie der Start und wie „Jetzt
  aktualisieren".

## [1.53.0] – 2026-09-22

### Neu

- **Der ganze Bestand als Datei — zum Archivieren und für andere
  Programme.** Unter *Mehr → Bestand exportieren* entsteht eine CSV-Datei mit
  allem, was die Wehr hat: Fahrzeug, Kennzeichen, Fach, Gerät, Stückzahl,
  geführte Einheiten samt Codes und Prüfterminen.

  Eine Zeile ist ein Gegenstand, so wie die App ihn kennt: Wo Einheiten
  einzeln geführt werden, steht jede für sich; der Rest der Stückzahl kommt
  als eine Sammelzeile dazu. **Die Summe der Anzahl bleibt dabei die
  Stückzahl** — sonst hätte ein anderes Programm nach dem Einlesen weniger
  Geräte als die Wehr.

  Was an keinem Fahrzeug hängt — Reserve, in Reparatur, noch nicht
  zugeordnet —, steht am Ende unter „Lager". Ein Verzeichnis, das das
  wegließe, wäre beim Archivieren falsch.

  Die Datei ist bewusst **herstellerneutral**: eine breite, sauber benannte
  Tabelle, die jedes Inventarprogramm einlesen kann. Sag Bescheid, welches
  System eure Wehr oder der Kreis einsetzt — dessen Format ist danach eine
  Zuordnung von Spalten, kein Neubau.

## [1.52.0] – 2026-09-22

### Neu

- **NFC-Tags: berühren statt anpeilen.** Ein QR-Aufkleber will angepeilt
  werden — Kamera drauf, Abstand, Licht. Ein NFC-Tag genügt es zu berühren.
  Im Geräteraum, halb im Dunkeln, mit Handschuhen ist das der schnellere Weg,
  und darum ging es bei diesem Wunsch: mit dem Handy am Fach entlang, statt
  fünfzehnmal zu zielen.

  In der Inventur liegt dafür ein eigener Knopf in der Leiste. Der Bildschirm
  bleibt offen und meldet jeden Fund, genau wie beim Scannen.

- **Ein Tag verknüpfen geht in einem Zug.** Die App schreibt ihren Code auf
  das Tag, wenn es das zulässt. Ist es schreibgeschützt — billige Aufkleber
  und Prüfplaketten oft sind es —, übernimmt sie stattdessen seine
  Seriennummer. Das Tag ist damit trotzdem brauchbar, statt abgelehnt zu
  werden.

  Ein Tag, das schon auf einem Gerät klebt, wird nicht überschrieben: Die App
  sagt, wo es sitzt.

- **Geräte ohne NFC merken nichts davon.** Die Knöpfe stehen nur dort, wo es
  NFC wirklich gibt. Im Browser und auf Geräten ohne Antenne bleibt alles
  beim Alten — Kamera und Tastatur.

## [1.51.1] – 2026-09-22

### Behoben

- **Unterlagen anhängen im Browser meldete eine Fehlermeldung aus dem
  Maschinenraum.** Wer im Browser eine Betriebsanleitung anhängen wollte,
  bekam `MissingPluginException(…getApplicationDocumentsDirectory…)` zu
  lesen, und angehängt war nichts. Der Grund: Im Browser gibt es keinen
  Platz auf dem Gerät, auf den die App die Datei legen könnte — und genau
  das ist hier die Zusage, nämlich lesbar zu sein, wenn kein Netz da ist.

  Im Browser steht jetzt statt des Knopfes, wo es geht: in der App. Ebenso
  beim Antippen einer Unterlage — vorher hieß es dort „ließ sich gerade
  nicht laden", was auf ein Netzproblem hindeutete, das es nicht gab.
  Android ist unverändert; dort funktioniert das Anhängen wie bisher.

## [1.51.0] – 2026-09-22

### Neu

- **Die Codes gelten jetzt für die ganze Abteilung.** Bisher kannte sie nur
  das Gerät, auf dem sie vergeben wurden: Der Gerätewart klebte die
  Aufkleber, und bei der nächsten Inventur stand jemand anderes mit seinem
  Handy davor und scannte ins Leere. Codes gehen jetzt beim Aktualisieren
  hoch und kommen bei allen anderen an — einzeln, nicht über den
  Gesamtbestand.

  Vergeben, Verknüpfen und Entfernen laufen weiter **ohne Netz**. Im
  Geräteraum ist selten welches, und ein Aufkleber, der erst mit Verbindung
  entstehen kann, wäre dort wertlos. Was noch nicht oben angekommen ist,
  steht unter dem Code: „noch nicht übertragen".

  Ein entfernter Code bleibt entfernt, auch wenn ein anderes Gerät ihn noch
  kennt — sonst käme der abgezogene Aufkleber beim nächsten Abgleich zurück.

### Hinweis für den Server

- Diese Version bringt die Migration `20260922080000_geraete_codes.sql` mit.
  Bis sie eingespielt ist, läuft die App unverändert weiter; die Codes
  bleiben dann auf dem Gerät, auf dem sie vergeben wurden.

## [1.50.0] – 2026-09-22

### Neu

- **Codes scannen statt eintippen.** In der Inventur liegt oben rechts jetzt
  ein Scanner: Kamera auf den Aufkleber halten, und das Gerät ist abgehakt.
  Der Sucher bleibt offen und meldet jeden Fund über dem Bild — ein Fach geht
  damit in einem Zug durch. Denselben Weg gibt es beim Verknüpfen eines Codes
  mit einem Gerät.

  Die Tastatureingabe bleibt daneben stehen. Sie ist der Weg, wenn die Kamera
  belegt ist, der Aufkleber zerkratzt oder das Gerät gar keine hat.

- **Vergebene Codes zeigt die App als QR zum Aufkleben.** Nach dem Vergeben
  steht er gleich groß auf dem Bildschirm, später genügt ein Tippen auf den
  Code. Darunter steht er zusätzlich als Text — ein verkratzter Aufkleber
  wäre sonst wertlos.

### Behoben

- **Ein Aufkleber zählt einmal, auch wenn die Kamera ihn hundertmal liest.**
  Beim Scannen liefert die Kamera denselben Code, solange er im Bild ist.
  Bisher stieg die Stückzahl dabei weiter — wer die Kamera ruhig hielt,
  meldete ein Fach als vollständig, das es nicht war. Die App merkt sich
  jetzt, welche Einheit schon gezählt wurde, und sagt es beim zweiten Mal.

- Auf Android fehlte der App die Kamera-Berechtigung. Das Fotografieren von
  Geräten lief trotzdem, weil dafür die Kamera-App des Systems geöffnet wird;
  der neue Scanner greift direkt zu und hätte ohne sie ein schwarzes Bild
  gezeigt.

## [1.49.0] – 2026-09-22

### Neu

- **Geräte bekommen einen Code, und die Inventur hakt danach ab.** Bei jeder
  Geräte-Einheit unter *Prüftermine* steht jetzt ein Abschnitt **Codes**. Dort
  kannst du entweder einen **eigenen Code vergeben** — zum Ausdrucken und
  Aufkleben — oder den Code **eintragen, der schon auf dem Gerät steht**, etwa
  den Barcode des Herstellers. Ein Gegenstand darf mehrere Codes tragen.

  In der Inventur liegt oben rechts **Code eingeben**: Code rein, und das
  Gerät ist abgehakt. Das Feld bleibt offen und leert sich, damit ein Fach in
  einem Rutsch durchgeht. Bei mehreren Stück zählt jeder Code ein Stück —
  „vollständig" wird die Zeile erst, wenn das Soll erreicht ist.

  Gehört der Code zu einem Gerät eines anderen Fahrzeugs, sagt die App, um
  welches es sich handelt, statt einfach nichts zu tun.

  Noch nicht dabei: die **Kamera**. Bis dahin tippst du den Code ein — oder
  ein Handscanner tut es für dich, der schreibt ohnehin in dieses Feld.
  Die Codes liegen vorerst nur auf diesem Gerät und werden noch nicht mit
  dem Server abgeglichen.

## [1.48.1] – 2026-09-21

### Geändert

- Bibliotheken auf den aktuellen Stand gebracht (Serverabgleich, Datenbank,
  Protokollierung). Für die Bedienung ändert sich nichts.

## [1.48.0] – 2026-09-21

### Neu

- **Der Inventurbericht geht jetzt als Datei raus.** Am Ende einer Inventur
  liegt oben rechts ein Teilen-Knopf: Der Bericht wandert als CSV-Datei ins
  Teilen-Blatt — an eine Mail, in einen Messenger oder in die Dateiablage.
  Der Dateiname trägt Fahrzeug und Datum, die Tabelle öffnet sich in Excel
  mit richtigen Umlauten, und jede Zeile nennt Fach, Gerät, Soll, Ist,
  Zustand und Notiz.

- **„In Reparatur" als eigener Zustand.** Bisher blieb bei einem Gerät, das
  zur Prüfung gegeben wurde, nur die Wahl zwischen „fehlt" und „beschädigt" —
  beides sagt etwas Falsches. Der neue Zustand steht in der Prüfliste, in der
  Zusammenfassung und im Bericht, und er gilt als geprüft: Eine komplett
  durchgegangene Inventur gilt damit auch dann als fertig, wenn etwas beim
  Prüfdienst liegt.

### Geändert

- Beim erneuten Öffnen eines Mangels steht der bereits vermerkte Zustand da.
  Vorher sprang die Auswahl zurück auf „fehlt" — wer nur die Notiz nachlesen
  wollte, hat ein beschädigtes Gerät stillschweigend zu einem fehlenden
  gemacht.

## [1.47.2] – 2026-09-21

### Geändert

- Bibliotheken auf den aktuellen Stand gebracht — Dateiauswahl, Teilen-Blatt,
  Navigation und Bild-Zwischenspeicher. Für die Bedienung ändert sich nichts;
  die App bleibt damit sicherheitstechnisch versorgt.

## [1.47.1] – 2026-09-21

### Geändert

- Unterbau auf Flutter 3.47.5 gehoben. Für die Bedienung ändert sich nichts;
  die App läuft auf aktuellerer Technik und bleibt damit sicherheitstechnisch
  versorgt.

## [1.47.0] – 2026-09-12

### Neu

- **Fragen als Tabelle einlesen.** Der Gerätewart kann Fragen jetzt aus einer
  CSV- oder Excel-Datei übernehmen, statt sie einzeln durch das Formular zu
  geben — in der Wissensdatenbank oben rechts. Wer vierzig Fragen aus einem
  Lernzielkatalog überträgt, braucht dafür keinen Abend mehr.

  Es gibt eine **Vorlage zum Herunterladen**, die schon zwei ausgefüllte
  Beispiele enthält: eines mit Quellenangabe, eines mit zwei richtigen
  Antworten. In der Spalte „richtig" darf stehen, was man ohnehin schreibt —
  `1`, `a`, `b)` oder `a, c` für mehrere.

  Eine Datei mit einem Tippfehler ist kein Fehlschlag: Die guten Zeilen werden
  angeboten, die anderen mit **ihrer Zeilennummer aus der
  Tabellenkalkulation** genannt. Fragen, die es schon gibt, werden erkannt und
  nicht doppelt angelegt — auch dann, wenn sie zweimal in derselben Datei
  stehen.

## [1.46.0] – 2026-09-11

### Neu

- **Fahrzeugkunde aus eurem eigenen Fuhrpark.** Der Party-Modus hat eine
  vierte Kategorie: **„Welcher Wagen?"** — „Auf welchem Fahrzeug liegt das?"
  und „Welches Kennzeichen hat dieses Fahrzeug?". Die Fragen entstehen beim
  Spielstart aus eurem echten Bestand, nicht aus einer Normtabelle: Wo der
  Spreizer liegt, weiß nur eure App.

  Gefragt wird nur, was eindeutig ist. Ein B-Druckschlauch liegt auf jedem
  Wagen — solche Geräte kommen gar nicht erst vor, weil die Frage sonst
  mehrere richtige Antworten hätte. Unter drei Fahrzeugen bleibt die Kategorie
  ganz weg; bei zwei Wagen wäre die falsche Antwort immer der jeweils andere.

## [1.45.0] – 2026-09-11

### Neu

- **Die App kennt jetzt euren Fuhrpark.** Aus dem mitgelieferten Gerätekatalog
  entstehen über hundert neue Fragen der Form „Wofür wird ein B-Druckschlauch
  typischerweise eingesetzt?" — und im Spiel kommen die zu **euren** Geräten
  bevorzugt dran. Nicht ausschließlich: Gerät, das ihr nicht habt, seht ihr
  bei jeder überörtlichen Hilfe, also mischt sich davon etwas darunter. In der
  Wissensdatenbank steht an jeder solchen Frage, ob das Gerät in eurem Bestand
  liegt.

  Der übrige Prüfungsstoff — Rechtskunde, ABC-Einsatz, Löschlehre, Funk —
  bleibt davon **völlig unberührt**. Er wird nicht seltener, nur weil jetzt
  Gerätefragen dazugekommen sind.

  Die Antworten stammen wörtlich aus dem Katalog und sind nicht neu erfunden.
  Sollte trotzdem eine Frage unglücklich sein: Seit v1.44.0 kann der
  Gerätewart sie abschalten, und jede und jeder kann einen Hinweis dazu
  abgeben.

## [1.44.0] – 2026-09-10

### Neu

- **Der Gerätewart bestimmt, was abgefragt wird.** Wer keine
  Atemschutzgeräteträger hat, schaltet „Atemschutz" ab; wer keinen A-Einsatz
  fährt, nur das Kapitel „Strahlenschutz". Der Schalter steht in der
  Wissensdatenbank unter dem gewählten Gebiet und gilt für die **ganze Wehr**,
  nicht nur für das eigene Handy. Abgeschaltete Fragen kommen im Quiz und im
  Party-Modus nicht mehr dran — nachlesen kann man sie weiterhin, sie sind
  nur als „abgeschaltet" gekennzeichnet. Wissen wird nicht versteckt, es wird
  nur nicht abgefragt.

- **Jede Frage lässt sich hinterfragen.** Unter jeder Frage steht jetzt ein
  Knopf „Hinweis". Damit meldet jeder mit Konto, was an einer Frage nicht
  stimmt — eine veraltete Antwort, ein Tippfehler, eine Fundstelle, die es so
  nicht mehr gibt. Wohin das geht, hängt an der Frage: Bei einer
  **mitgelieferten** Frage, die in jeder Wehr dieselbe ist, geht der Hinweis
  an die Entwicklung; bei einer **eigenen** Frage eurer Wehr an euren
  Gerätewart, und er bleibt in der Wehr. Der Dialog sagt vorher, welcher der
  beiden Wege es ist. Offene Hinweise stehen beim Gerätewart ganz oben in der
  Wissensdatenbank, gleich neben dem, was auf Freigabe wartet.

## [1.43.0] – 2026-08-28

### Neu

- **Der ABC-Einsatz ist da — 50 Fragen mit Bildern.** Das letzte große leere
  Sachgebiet ist gefüllt, und weil „Gefahrgut" als ein Topf eine Liste wäre,
  in der niemand gezielt übt, hat es jetzt **Unterkapitel**:
  - **Gefahrzettel und Kennzeichnung** (15) — mit Bild. Elf Fragen zeigen
    einen Gefahrzettel oder eine orangefarbene Warntafel und fragen, was er
    bedeutet. Genau so steht man auch an der Einsatzstelle davor.
  - **Gefahrengruppen** (6), **Erstmaßnahmen und Bereiche** (8) mit der
    GAMS-Regel und den 50/100 Metern, **Schutzausrüstung** (5) mit den
    Formen 1 bis 3, **Dekontamination** (7) mit den drei Dekon-Stufen,
    **Aufgaben im ABC-Einsatz** (4) und **Strahlenschutz** (5).
- **Fragen können jetzt ein Bild tragen.** Bei einem Gefahrzettel ist das
  Bild die Frage — „rote Raute mit weißer Flamme" wäre schon die Antwort.
  Das Bild steht in der Wissensdatenbank und im Party-Modus.
- **Filter nach Unterkapitel.** Wählst du ein Sachgebiet mit Kapiteln, kommt
  darunter eine zweite Zeile: „Dekontamination (7)", „Gefahrzettel und
  Kennzeichnung (15)". Damit übt man den Teil, den man nicht kann, statt
  einmal quer durch alles.

### Hinweis zu den Quellen

Die Fragen stammen aus der FwDV 500 „Einheiten im ABC-Einsatz" (Neufassung
Januar 2022) und aus dem ADR, das in Deutschland im Bundesgesetzblatt
verkündet wird — beides amtliche Werke. **Die Gefahrzettel sind selbst
gezeichnet**, nach den Angaben des ADR (Symbol, Farbe, Hintergrund, Ziffer);
es ist kein Bild irgendwo heruntergeladen.

## [1.42.0] – 2026-08-28

### Neu

- **Funk, Technische Hilfeleistung und Löschlehre sind jetzt gefüllt.** Drei
  Sachgebiete, die vorher leer oder fast leer waren, haben zusammen 47 neue
  Fragen bekommen:
  - **Funk** (18) aus der FwDV 810 „Sprech- und Datenfunkverkehr": Anruf und
    Anrufantwort im Wortlaut, „Ich buchstabiere", „Ich berichtige", wann ein
    Notruf ausgelöst werden darf und was dann im Netz passiert.
  - **Technische Hilfeleistung** (17) aus der FwDV 3 und der FwDV 1: Aufgaben
    der Trupps im Hilfeleistungseinsatz, Ordnung des Raumes — und die
    Absicherung gegen den fließenden Verkehr mit ihren 200 Metern außerorts.
  - **Löschlehre** (12) aus der FwDV 1 und der ASR A2.2: Brandklassen von A
    bis F, die Handhabung der Strahlrohre und warum es keine Brandklasse E
    mehr gibt.
- **Sechs Fragen zum Verkehrsrecht** aus der Straßenverkehrs-Ordnung:
  Sonderrecht und Wegerecht, blaues und gelbes Blinklicht. Der Unterschied
  zwischen „ich darf" und „die anderen müssen" steht in zwei verschiedenen
  Paragraphen, und das ist der Punkt.

### Besser

- **Jede Fundstelle ist antippbar.** Auch die bisherigen Fragen tragen jetzt
  den Link zu ihrer Vorschrift — die Dienstvorschriften liegen bei der
  Landesfeuerwehrschule, Gesetze beim Bund. Wer nachlesen will, tippt darauf
  statt abzutippen.

### Hinweis zu den Quellen

Neu hinzugekommen sind die Straßenverkehrs-Ordnung (Rechtsverordnung des
Bundes) und die ASR A2.2 „Maßnahmen gegen Brände", die das Bundesministerium
für Arbeit und Soziales im Gemeinsamen Ministerialblatt bekannt macht. Beide
sind amtliche Werke. Aus den Lehrstoffblättern der Landesfeuerwehrschule und
aus DIN-Normtexten wird weiterhin **nichts** übernommen.

## [1.41.0] – 2026-08-28

### Neu

- **35 Fachfragen zum Start.** Der erste Teil des Theoriebestands ist da:
  Einsatzlehre und Taktik, Gerätekunde, Atemschutz und Löschlehre — aus den
  Feuerwehr-Dienstvorschriften **selbst formuliert**, jede Frage mit ihrer
  Fundstelle. Also nicht „ein Trupp besteht aus zwei Kräften", sondern
  „FwDV 3 · Abschnitt 2.1" daneben, damit du es nachschlagen kannst.
- **65 Fragen zum Landesrecht Baden-Württemberg.** Wer wählt den
  Kommandanten, wann ist ein Einsatz kostenpflichtig, ab wann darf man in
  die Einsatzabteilung, welcher Dienstgrad kommt nach dem Löschmeister —
  aus dem Feuerwehrgesetz und den beiden Verwaltungsvorschriften des Landes,
  ebenfalls mit Fundstelle. Fragen, die nur hier gelten, sagen das auch:
  „gilt in Baden-Württemberg" steht dabei.
- **Zwei neue Sachgebiete:** Atemschutz und Einsatzlehre. Beides sind eigene
  Lehrgänge, und unter „Gerätekunde" wären sie nicht wiederzufinden gewesen.
- Fragen dürfen jetzt bis zu zehn Antwortmöglichkeiten haben. Sechs war
  geraten — im amtlichen Prüfungsstoff laufen die Antworten bis „j)".

### Besser

- **Der Party-Modus nennt jetzt die Fundstelle.** Nach dem Antworten steht
  unter der Auflösung, woher die Antwort stammt — antippen öffnet die
  amtliche Fassung im Browser. Genau am Tisch wird über eine Antwort
  gestritten, und dort soll die Vorschrift entscheiden und nicht die
  lauteste Stimme.

### Hinweis zu den Quellen

Verwendet werden ausschließlich amtliche Werke: die Feuerwehr-Dienst&shy;vor&shy;schriften,
das Unfallverhütungsrecht sowie das Feuerwehrgesetz Baden-Württemberg und
seine Verwaltungsvorschriften. Aus den Lehrstoffblättern der
Landesfeuerwehrschule wird **nichts** übernommen — die erscheinen im Verlag.
Aus DIN-Normen ebenfalls nicht; ein Sachverhalt daraus ist frei, der
Normtext nicht.

## [1.40.0] – 2026-08-27

### Neu

- **Fragen dürfen mehrere richtige Antworten haben.** Im amtlichen
  Prüfungsstoff ist das der Normalfall, nicht die Ausnahme: Im Fragenkatalog
  des Innenministeriums zum Leistungsabzeichen haben nur 79 von 210 Fragen
  genau eine richtige Antwort. Beim Anlegen hakst du deshalb alle richtigen
  an; richtig beantwortet ist eine Frage, wenn **alle** richtigen und
  **keine** falsche angekreuzt sind.
- **Jede Frage kann ihre Quelle nennen.** Werk und Fundstelle — etwa
  „FwG BW · § 8 Abs. 2" oder „FwDV 10 · Abschnitt 4.2" — stehen in der
  Wissensdatenbank unter der Frage. Eine Antwort, die man nicht nachschlagen
  kann, nützt im Zweifel wenig, und im Zweifel ist man im Einsatz.
- **Bundesweit oder Landesrecht.** Fachliches aus den Dienstvorschriften gilt
  überall gleich; das Feuerwehrgesetz und die Rangordnung sind Landesrecht.
  Fragen tragen das jetzt sichtbar, und Landesrecht wird beim Namen genannt.

### Geändert

- Der Party-Modus zieht nur Fragen mit **einer** richtigen Antwort. Am Tisch
  reihum ist Mehrfach-Ankreuzen kein Spielzug — die übrigen Fragen bleiben in
  der Wissensdatenbank, sie werden dort nur nicht gestellt.

## [1.39.0] – 2026-08-27

### Neu

- **Wissensdatenbank.** Die Fragen hinter den Quizzen sind jetzt ein
  durchsuchbarer Bestand statt drei getrennter Töpfe — zu finden unter
  *Lernen → Wissensdatenbank*. Jede Frage hat ein Sachgebiet:
  Fahrzeugkunde, Gerätekunde, Löschlehre, Technische Hilfeleistung,
  Gefahrgut, Erste Hilfe, Recht und Organisation, Funk — und getrennt davon
  die Klischees, damit niemand sie für Prüfungsstoff hält.
- **Jeder darf eine Frage beisteuern.** Wer ein Konto hat, kann eine Frage
  einreichen; das Formular führt durch Frage, Antworten und Erklärung und
  sagt in einem Satz, was noch fehlt. **Freigegeben wird sie vom
  Gerätewart** — bis dahin steht sie sichtbar auf dem Stapel, aber sie wird
  nicht gestellt.
- **Freigegebene Fragen spielen sofort mit.** Der Party-Modus zieht seinen
  Topf mit den unerwarteten Fragen ab jetzt aus der Wissensdatenbank statt
  aus einer festen Datei. Was die Wehr beisteuert, ist am selben Abend im
  Spiel.
- Die 32 mitgelieferten Fragen sind eingeordnet und bleiben der Grundstock.
  Sie lassen sich nicht löschen — sie kämen beim nächsten Start ohnehin
  wieder.

### Hinweis

Die Fragen gehören der **Gesamtwehr**, nicht der einzelnen Abteilung: Ein
B-Schlauch hat überall denselben Durchmesser. Was eine Abteilung beisteuert,
steht nach dem nächsten Abgleich allen Abteilungen der Wehr zur Verfügung.

## [1.38.0] – 2026-08-27

### Neu

- **Fotos für einzelne Geräteräume.** Jedes Fach kann jetzt ein Bild
  bekommen — unter *Fächer verwalten* auf das Kästchen neben dem Fach tippen.
  In der Fahrzeugansicht steht das Foto über der Geräteliste des Fachs: Wer
  nachts nachlädt, vergleicht schneller ein Bild, als er eine Liste liest.
  Langes Tippen entfernt das Foto wieder. Das gilt auch für Transportwägen
  und Rollcontainer — die werden als Geräteraum angelegt.
- **Unterlagen am Fahrzeug.** Betriebsanleitung, Fahrzeugschein,
  Prüfbescheinigung: PDF oder Foto, direkt am Fahrzeug, gleich unter dem
  Kopfbereich. Angehängt wird über *Anhängen*, geöffnet mit einem Tipp.
- **Und zwar auch ohne Netz.** Das ist der eigentliche Punkt: Ein Fahrzeug
  steht selten im WLAN. Jede Unterlage sagt deshalb, ob sie **auf diesem
  Gerät** liegt oder nur auf dem Server, und ein Knopf holt alles Fehlende
  auf einmal herunter. Was du einmal geöffnet hast, bleibt da.

### Hinweis für den Gerätewart

Die Fach-Fotos wandern über die normale Veröffentlichung mit. Damit sie auf
den Geräten der Kameraden ankommen, muss dort **mindestens diese Version**
installiert sein — eine ältere App kennt die Fotos nicht und würde sie beim
Veröffentlichen wieder entfernen. Die Unterlagen sind davon nicht betroffen,
die gehen einen eigenen Weg.

## [1.37.0] – 2026-08-27

### Neu

- **Gerätesuche: „Wo liegt das?"** Bisher konnte die App nur den Katalog
  durchsuchen — also welche Geräte es gibt. Wo eines davon verlastet ist,
  stand nirgends; man klickte sich Fahrzeug für Fahrzeug durch die Fächer.
  Jetzt gibt es eine Suche, die **Fahrzeug und Fach** nennt, mit Farbpunkt und
  Ortsangabe wie im Fahrzeugmenü, und mit der Stückzahl, wenn mehrere in einem
  Fach liegen.
- **Zwei Wege hin:** eine Kachel ganz oben auf der Startseite für den
  ganzen Fuhrpark, und die Lupe in einer Fahrzeugansicht für dieses
  Fahrzeug. Die Kachel steht bewusst über Serie und Wochenziel — „Wo
  liegt das?" fragt man unter Zeitdruck.
- **Am Fahrzeug sucht sie im Fahrzeug.** Die Lupe in einer Fahrzeugansicht
  öffnet dieselbe Suche, aber auf dieses Fahrzeug eingegrenzt. Liegt das
  gesuchte Gerät nicht darin, sagt sie nicht „nichts gefunden", sondern
  **wo es stattdessen liegt** — im Einsatz die eigentliche Auskunft.
- **Sie verzeiht beim Tippen.** Umlaute sind egal („schlauche" findet
  „C-Schläuche"), der Kurzname zählt mit („C42"), und mehrere Wörter dürfen in
  beliebiger Reihenfolge stehen („schere akku" findet die
  „Akku-Rettungsschere").
- **Was noch nicht verlastet ist, wird als solches gemeldet.** Steht ein Gerät
  im Katalog, aber in keinem Fahrzeug, sagt die Suche genau das, statt „nichts
  gefunden" zu behaupten.

### Geändert

- Die Lupe in der Fahrzeugliste führt jetzt in die Gerätesuche statt in den
  Gerätekatalog. Der Katalog bleibt unter **Mehr → Geräte** erreichbar.

## [1.36.0] – 2026-08-26

### Behoben

- **Der Feedback-Banner bleibt nach dem Senden stehen.** Wer einen Wunsch
  abgeschickt hatte, verlor damit den Zugang zum Dialog: Das Banner
  verschwand bis zum nächsten App-Start, und die zweite Idee musste warten.
  Es geht jetzt erst weg, wenn du es selbst wegklickst — und auch dann nur
  für diese Sitzung.

## [1.35.0] – 2026-08-26

### Behoben

- **Der Party-Modus nennt jetzt das Fahrzeug.** „In welchem Fach liegt das?"
  war bei mehr als einem Fahrzeug nicht zu beantworten: Zur Wahl standen vier
  Fachnamen, aber von welchem Wagen sie stammen, stand erst in der Auflösung —
  also nach der Antwort. Das Fahrzeug steht jetzt über der Frage.
- **Lange Fahrzeugnamen passen wieder in die Auswahl.** Beim Aufbau einer
  Partie lief ein Name wie „HLF 20/16 Florian Musterstadt 1/44" auf einem
  Handy über den Rand hinaus; zu sehen war statt des Namens eine
  gelb-schwarze Warnfläche. Der Name wird jetzt gekürzt statt überzulaufen.

### Geändert

- **Eine Runde bleibt bei einer Kategorie.** Innerhalb eines Umlaufs bekommen
  alle Spieler dieselbe Art Frage — entweder „Wo liegt was?", „Was ist das?"
  oder Unerwartetes. Vorher wechselte die Art bei fast jeder Frage: Einer
  durfte ein Klischee raten, während der Nächste ein Fach auswendig wissen
  musste. Der Übergabe-Schirm sagt die Kategorie der Runde jetzt mit an.

## [1.34.0] – 2026-08-22

### Neu

- **Party-Modus.** Ein Handy, alle am Tisch: Namen eintragen, und das Gerät
  geht reihum. Wer dran ist, bekommt einen Übergabe-Schirm zu sehen, bevor die
  Frage erscheint — so liest der Vorgänger nicht mit. Die Fragen kommen aus
  drei Töpfen: Wo liegt welches Gerät, was ist auf dem Bild zu sehen, und ein
  neuer Topf mit **unerwarteten Fragen** aus Feuerwehrwissen und Klischees.
  Der Topf funktioniert auch auf einem frisch eingerichteten Gerät, also noch
  bevor ein Fahrzeug angelegt ist.
- **Trinkspiel, ausdrücklich abschaltbar.** Der Schalter ist ab Werk aus. Ist
  er an, schlägt das Spiel bei einer falschen Antwort „einen Schluck — oder"
  eine Aufgabe vor, und zwar gleichwertig: Wer Bereitschaft hat, nimmt die
  Aufgabe. Der Hinweis steht im Aufbau mit dabei.
- Die Antworten des Party-Modus tragen dieselben Seitenfarben und Ortsangaben
  wie das Fahrzeugmenü und das Fach-Quiz.

### Geändert

- Am Ende einer Partie steht bei Gleichstand **„Unentschieden"** statt eines
  Siegers, der nur zufällig zuerst eingetragen wurde. Gleiche Punktzahl heißt
  gleicher Platz.

### Hinweis

Der Party-Modus rührt die persönliche Lernstatistik **nicht** an: Wer an
diesem Abend auf dem Handy mitspielt, verändert weder XP noch Serie noch die
Ergebnisliste des Besitzers.

## [1.33.0] – 2026-08-22

### Neu

- **Vorabversionen erhalten.** In den Einstellungen unter „App-Information"
  gibt es einen neuen Schalter. Ist er an, bietet die App auch Stände an,
  die noch nicht freigegeben sind — gedacht zum Ausprobieren, bevor eine
  Version an die ganze Wehr geht. Der Schalter ist ab Werk aus und **gilt
  nur für das Gerät, auf dem er umgelegt wird**; niemand sonst bekommt
  dadurch Vorabversionen angeboten. In der Web-App gibt es ihn nicht: Dort
  ist beim nächsten Neuladen ohnehin der aktuelle Stand geladen.
- **Das Banner sagt, was es anbietet.** Ein noch nicht freigegebener Stand
  erscheint als „🧪 Vorabversion v… verfügbar", und im Dialog steht vor dem
  Installieren noch einmal, dass es ein Zwischenstand ist.

## [1.32.0] – 2026-08-22

### Geändert

- **Die Farben der Fahrzeugseiten gelten jetzt überall.** Bisher war das
  Fahrzeug nur in der Draufsicht bunt — im aufgeklappten Bild, beim
  Drag & Drop, in der Inventur, in der Einsatzplanung und in der
  Fächerverwaltung blieben dieselben Fächer grau. Jetzt trägt jedes Fach
  seine Seitenfarbe in jeder Ansicht: Fahrerseite blau, Beifahrerseite
  rostrot, Heck grün, Dach ocker, Front violett. Beim Üben stechen Grün und
  Rot die Seitenfarbe weiterhin — die Rückmeldung bleibt eindeutig.
- **Das Fach-Quiz sagt, wo die Fächer liegen.** Die Antworten hießen bisher
  nur „G5" oder „Dach". Jetzt steht der Farbpunkt davor und die Ortsangabe
  darunter („Fahrerseite · hinten") — bei allen vier Antworten, es ist also
  kein Hinweis auf die richtige, sondern die Gelegenheit, die Konvention
  nebenbei zu lernen.

### Neu

- **Das mitgelieferte Demo-Fahrzeug ist verortet.** Direkt nach der
  Installation — also bevor die eigenen Daten da sind — zeigt die App die
  Draufsicht mit farbigen Geräteräumen statt einer grauen Kachelreihe. Auf
  Geräten, die schon vorher installiert waren, wird die Verortung
  nachgetragen; selbst gesetzte Seiten bleiben unangetastet.

## [1.31.0] – 2026-08-21

### Neu

- **Zugangsdaten teilen statt abtippen.** Wer ein Konto mit Zugangszettel
  anlegt, findet im Dialog jetzt neben „Kopieren" auch **„Teilen"** — die
  Zugangsdaten wandern damit als fertige Nachricht in WhatsApp, Signal oder
  SMS. Dass das gefahrlos geht, liegt am Pflichtwechsel: Beim ersten
  Anmelden wählt die Person ein eigenes Passwort, danach ist die
  verschickte Nachricht wertlos.
- **Demo-Zugang zum Weitergeben.** In der Nutzerverwaltung teilt ein Knopf
  einen Blick in die erfundene Wehr „Feuerwehr Freiwilligen" — für alle,
  die erst einmal schauen wollen, ohne einen eigenen Zugang zu brauchen.
  Dahinter liegen erfundene Fahrzeuge und kein einziges echtes Wehrdatum,
  und der Zugang liest nur.

## [1.30.0] – 2026-08-17

### Neu

- **Fahrzeug aus Vorlage: Beladung auf Wunsch gleich in die Geräteräume.**
  Beim LF 20 und HLF 20 lässt sich die Normbeladung jetzt beim Anlegen nach
  der verbreiteten Konvention auf die Fächer verteilen — Atemschutz in den
  Mannschaftsraum, Stromerzeuger in G1, Schläuche in G3, der
  Rettungssatz in G2 … Wer den Schalter nicht setzt, bekommt wie bisher
  alles gesammelt in ein Fach. Die Verteilung ist eine ungeprüfte
  Vorbelegung: bitte am eigenen Fahrzeug prüfen, jede Position bleibt
  einzeln änderbar.
- Die Vorlagen für LF 20 und HLF 20 bringen dafür ein neues Fach
  **„Mannschaftsraum"** mit — dort liegen Pressluftatmer, Masken,
  Feuerwehrleinen und Funkgeräte.

## [1.29.0] – 2026-08-06

### Neu

- **Mehrere Geräte auf einmal einsortieren.** Im Geräte-Wähler hakt ein Tipp
  jetzt an, statt sofort zuzuweisen und zu schließen — angehakt wird, was ins
  Fach gehört, und ein Knopf legt alles gemeinsam hinein. Die Auswahl bleibt
  auch dann bestehen, wenn zwischendurch neu gesucht wird: erst „Schlauch"
  suchen und drei anhaken, dann „Strahlrohr" und zwei.
- **Geräte lassen sich gemeinsam in ein anderes Fach schieben.** Ein langer
  Druck auf ein Gerät im Fach öffnet die Auswahl; danach reicht ein Tipp je
  weiterem Gerät. Über *Verschieben* wandern sie zusammen ins gewählte Fach,
  über das Papierkorb-Symbol gemeinsam heraus.

  Damit lässt sich vor allem das Sammelfach „Normbeladung (ungeprüft) – noch
  zuzuordnen" auflösen, das eine Fahrzeug-Vorlage anlegt: am Fahrzeug stehen,
  die Geräte eines Faches markieren, verschieben, weiter zum nächsten. Vorher
  war das ein Handgriff je Gerät — bei einer vollständigen Beladung mehrere
  hundert.

### Behoben

- Ein Gerät, das in ein Fach verschoben wird, in dem es bereits liegt, taucht
  dort nicht mehr doppelt auf: Die Stückzahlen werden zusammengezählt.

## [1.28.0] – 2026-08-05

### Neu

- **Fahrzeug-Vorlagen kommen fertig verortet.** Wer ein Fahrzeug aus einer
  Vorlage anlegt, bekommt Seiten und Positionen gleich mit — die Draufsicht
  steht ab der ersten Sekunde. Vorbelegt ist die verbreitete Konvention;
  der Hinweis der Vorlage sagt es dazu, und jedes Fach lässt sich einzeln
  ändern.
- **Zwei neue Vorlagen: TLF 3000 und TLF 4000.** Beide mit der üblichen
  Trupp-Aufteilung (G1–G4, Heck, Dach), ohne Beladeliste — für die gibt es
  keine öffentlich belegbare Quelle.
- **Der Feedback-Dialog kennt jetzt vier Arten.** Neben Wunsch und Fehler
  kannst du eine fehlende Fahrzeug-Vorlage 🚒 oder ein fehlendes
  Standard-Gerät 🧰 vorschlagen. Die erste Zeile deiner Nachricht wird
  dabei die Überschrift beim Entwickler — der Hinweis im Dialog erinnert
  daran.

## [1.27.0] – 2026-08-05

### Neu

- **Die Fahrzeugübersicht zeigt jetzt eine Draufsicht.** Fahrtrichtung nach
  oben: Front oben, Fahrerseite links, Dach in der Mitte, Beifahrerseite
  rechts, Heck unten — ein Blick aufs Schema statt einer Liste im Kopf.
  Das Aufklappbild bleibt als zweite Ansicht erreichbar, und ohne
  Seitenangaben sieht alles aus wie bisher.
- **Jede Seite hat ihre feste Farbe.** Beifahrerseite warm, Fahrerseite
  kühl, Heck grün, Dach ocker, Front violett — im Schema, in der
  Fächerliste und im Fach. Die Farben bleiben gleich, egal welche
  Farbpalette du wählst: Sie sind die Merkhilfe, kein Schmuck.
- **Fächer haben jetzt eine Position an der Seite: vorne, Mitte oder
  hinten.** Sie wird wie die Seite aus dem Namen vorgeschlagen (G1/G2
  vorne, G3/G4 Mitte, G5/G6 hinten) und erst übernommen, wenn du
  bestätigst. Der Knopf in der Fächerverwaltung heißt jetzt „Verortung
  aus den Namen vorschlagen" und füllt auch bei schon zugewiesenen Seiten
  die fehlenden Positionen nach.
- **Das Fach beantwortet „wo finde ich das?".** Beim Antippen zeigt sein
  Kopf Seite und Position in der Seitenfarbe, dazu die Leiste
  Front · vorne · Mitte · hinten · Heck und ein Mini-Schema mit dem
  markierten Fach.
- **„Wo liegt's?" fragt auf demselben Bild ab.** Sobald ein Fahrzeug
  verortet ist, tippst du im Quiz auf die Draufsicht — gelernt wird am
  gleichen Schema, das auch die Übersicht zeigt.

### Behoben

- **Das Quiz und Drag & Drop kannten die Seiten nicht.** Beide zeigten das
  Fahrzeug ohne Bereiche, auch wenn Seiten längst zugewiesen waren.

## [1.26.0] – 2026-08-05

### Neu

- **Du siehst jetzt, ob eine Einladung angekommen ist.** Bisher stand an
  jeder offenen Einladung dasselbe — „wartet auf Bestätigung", auch wenn die
  Mail längst verworfen worden war. In der Nutzerverwaltung steht jetzt
  darunter, ob sie zugestellt wurde, noch unterwegs ist oder **unzustellbar**
  war; im letzten Fall mit Grund und Zeitpunkt.
- **Der Ausweg steht direkt an der Einladung.** Über das Menü der Zeile legst
  du stattdessen ein Konto mit Zugangszettel an — Nutzername, Rolle und
  Abteilung sind schon ausgefüllt, und die tote Einladung wird dabei
  zurückgezogen.

### Gut zu wissen

- **„Zustellung nicht prüfbar" heißt genau das.** Kann der Server die
  Auskunft nicht einholen, steht das da — und ausdrücklich nicht „alles in
  Ordnung". Genau diese Verwechslung war das Problem.
- **Ob jemand die Mail geöffnet hat, steht nirgends.** Postfach-Scanner
  melden ein „geöffnet" wenige Sekunden nach dem Versand, ohne dass ein
  Mensch die Mail gesehen hat. Das wäre keine Auskunft, sondern eine falsche.

## [1.25.0] – 2026-08-04

### Neu

- **Leistungsabzeichen fürs Lernen.** Wer übt, steigt im Level — und ab
  Level 3 hängt ein Leistungsabzeichen in **Bronze** am eigenen Avatar, ab
  Level 8 in **Silber**, ab Level 15 in **Gold**. Es steht in „Mein Profil",
  in der Einstellungs-Kachel und auf der Level-Karte der Startseite, jeweils
  mit der Angabe, wie weit es bis zur nächsten Stufe ist.

### Gut zu wissen

- **Einmal verliehen, bleibt verliehen.** Ein Abzeichen verschwindet nicht
  wieder, wenn du zwei Wochen nicht übst.
- **Bewusst kein Dienstgrad.** Schulterklappen mit Sternen und Balken stehen
  für ein Amt mit echter Weisungsbefugnis — die gibt es nicht fürs Quiz. Das
  Leistungsabzeichen wird dagegen für gezeigtes Können verliehen, und genau
  das ist hier gemeint.
- **Die Stufe bleibt auf deinem Gerät.** Sie entsteht aus deinen
  Lernergebnissen, und die verlassen das Handy nicht. Deshalb steht das
  Abzeichen auch nur an deinem eigenen Kopf und nicht in der
  Nutzerverwaltung.

## [1.24.0] – 2026-08-04

### Neu

- **Der Beladeplan sieht jetzt aus wie das Fahrzeug.** Jedes Fach bekommt
  eine Seite — Dach, Front, Fahrerseite, Heck oder Beifahrerseite — und die
  Schnittdarstellung klappt das Fahrzeug entsprechend auf: Dach oben, dann
  einmal herum. Wer davorsteht, findet das Fach an derselben Stelle wieder.
- **Seiten für den Bestand vorschlagen lassen.** In der Fächerverwaltung
  ordnet ein Knopf alle Fächer auf einmal zu, abgeleitet aus ihren Namen
  (ungerade Geräteräume Fahrerseite, gerade Beifahrerseite, GR ans Heck).
  Der Vorschlag wird vorher vollständig angezeigt und erst nach deinem Ja
  übernommen.

### Gut zu wissen

- **Nichts wird still verschoben.** Fächer ohne Seite bleiben sichtbar, in
  einem eigenen Bereich am Ende. Und der Vorschlag rührt kein Fach an, dem
  du selbst schon eine Seite gegeben hast.
- **Fahrerseite statt links** — „links" hängt davon ab, ob man vor oder
  hinter dem Fahrzeug steht.

## [1.23.0] – 2026-08-04

### Geändert

- **Die Einladungsmail kommt mit dem Namen eurer Wehr an.** Betreff und
  Überschrift nennen jetzt die Gesamtfeuerwehr statt „Willkommen bei der
  FWApp" — im Postfach sieht die Einladung damit nach Feuerwehr aus und
  nicht nach Werbung. Abteilung und Rolle stehen wie bisher darunter.

### Behoben

- Stand keine Gesamtwehr dahinter, las sich die Einladung als „Du wurdest
  für deiner Feuerwehr eingeladen". Der Satz ist weg; die Wehr steht in der
  Überschrift.

## [1.22.0] – 2026-08-04

### Neu

- **Die App begrüßt dich beim Start.** Eine kurze Animation: die Flamme geht
  auf, ein Wasserstrahl löscht sie, daraus wird das Logo. Sie läuft in voller
  Länge nur nach der Installation und nach einem Update — sonst siehst du
  bloß kurz das Logo, damit das zweite Öffnen im Gerätehaus nicht wartet.

### Gut zu wissen

- **Sie hält nichts auf.** Die App baut darunter schon auf; wenn die
  Animation endet, ist sie sofort da. Ein Tipp auf den Bildschirm bricht ab.
- **Wer Animationen abgeschaltet hat** (Bedienungshilfen des Geräts), bekommt
  immer die kurze Fassung.

## [1.21.0] – 2026-08-04

### Neu

- **Fahrzeuge lassen sich wieder entfernen.** Auf der Fahrzeugseite steht im
  ⋮-Menü jetzt *Fahrzeug entfernen*. Bisher blieb ein einmal angelegtes
  Fahrzeug für immer stehen — auch ein Vertipper beim Erfassen. Vor dem
  Entfernen steht, was mitgeht: die Fächer und die Beladeliste. Die Geräte
  selbst bleiben im Bestand, nur ihre Zuordnung zu diesem Fahrzeug entfällt;
  prüfpflichtige Exemplare behalten ihre Prüfhistorie und verlieren nur den
  Standort.

### Gut zu wissen

- **Entfernen darf, wer bearbeiten darf.** Wer nur lesen kann, sieht den
  Menüpunkt nicht.
- **Rückgängig machen geht nicht.** Deshalb die Rückfrage mit den Zahlen —
  und deshalb steht die Aktion im Menü statt als eigenes Symbol neben
  „Bearbeiten".

## [1.20.0] – 2026-08-04

### Neu

- **Eigener Anzeigename und eigener Avatar.** Unter *Einstellungen → Mein
  Profil* legst du fest, wie du in der Nutzerverwaltung stehst: mit deinem
  Namen statt mit der Kennung vom Zugangszettel, und mit einem Kopf, den du
  dir aussuchst. 36 fertige Köpfe stehen bereit — vom Atemschutzgeräteträger
  über den Maschinisten bis zum Dalmatiner — und wer mag, stellt sich im
  Baukasten seinen eigenen zusammen: Helm, Augen, Mund, Bart, Hautton,
  Haarfarbe, Hintergrund. „Zufällig würfeln" geht auch.

### Gut zu wissen

- **Der Kopf ist gezeichnet, kein Foto.** Gespeichert werden acht Werte, kein
  Bild. Das lädt nichts hoch, braucht kein Netz zum Anzeigen und legt kein
  Gesicht einer echten Person in der Datenbank ab.
- **Dein Nutzername bleibt, wie er ist.** Er ist die Anmeldung und wird
  weiterhin vom Kommandanten vergeben; in der Nutzerverwaltung steht er
  neben deinem Anzeigenamen, damit beim Passwort-Zurücksetzen klar bleibt,
  wer gemeint ist.
- **Beides gehört dir.** Anzeigename und Avatar kann nur das Konto selbst
  setzen — auch der Kommandant nicht.

## [1.19.0] – 2026-08-04

### Neu

- **Übungsrechte: Gerätewarte können Truppführern befristet Schreibrechte
  geben.** In der Nutzerverwaltung steht beim Konto jetzt *Übungsrechte
  erteilen* — bis Tagesende, zwei oder vier Stunden. Der Betreffende darf
  danach Fahrzeuge, Fächer und Geräte anlegen und ändern, genau wie ein
  Gerätewart, und sieht auf der Startseite bis wann. Gedacht für die Übung:
  Wer mitschreibt, muss dafür nicht dauerhaft Gerätewart werden.

### Gut zu wissen

- **Verwalten bleibt außen vor.** Übungsrechte schalten das Bearbeiten frei,
  niemals die Nutzerverwaltung — und wer sie hat, kann sie nicht selbst
  weitergeben.
- **Erteilen darf, wer selbst schreiben darf**: der Gerätewart, der
  Abteilungskommandant, der Feuerwehrkommandant. Nicht nötig, dafür jemanden
  zu holen.
- **Beenden wirkt sofort**, und jedes Erteilen und Beenden bleibt
  nachvollziehbar: wer wem wann.
- **Nur online.** Rechteänderungen erreichen ein Gerät nur mit Verbindung —
  also vor der Übung erteilen, nicht unten im Keller.

## [1.18.1] – 2026-08-04

### Behoben

- **Passwortmanager erkennen die Passwortfelder wieder.** Beim Zurücksetzen
  des Passworts und beim Einlösen einer Einladung boten Bitwarden & Co.
  nichts an, und „generiertes Passwort einfügen" tat sichtbar nichts. Ursache
  war im Browser messbar: Die App meldete dem Browser weiterhin das
  Anmeldeformular, während längst die Felder für ein neues Passwort auf dem
  Bildschirm standen.

### Gut zu wissen

- Auf dem Bildschirm **„Neues Passwort festlegen"** (Pflichtwechsel nach der
  ersten Anmeldung mit einem Zugangszettel) hilft der Manager erst, nachdem
  man einmal ins Feld getippt hat. Danach füllt er beide Felder normal.

## [1.18.0] – 2026-08-03

### Neu

- **Abteilungen und die Gesamtwehr lassen sich umbenennen.** Unter
  *Mehr → Abteilung & Gesamtwehr* steht neben jedem Namen ein Stift. Der
  Abteilungskommandant ändert den Namen seiner Abteilung, der
  Feuerwehrkommandant jeden Namen seiner Wehr — auch den der Wehr selbst.
  Bisher stand ein Name fest, sobald er einmal vergeben war: Ein Tippfehler
  im Abteilungsnamen war nur noch am Server zu heilen.

### Gut zu wissen

- Beim Umbenennen ändert sich **nur die Beschriftung**. Alles, was an einer
  Abteilung hängt — Fahrzeuge, Geräte, Mitgliedschaften, Prüfungen —, bleibt
  unangetastet, und alle Geräte sehen den neuen Namen beim nächsten Abgleich.

## [1.17.0] – 2026-08-03

### Neu

- **Kommandanten laden neue Leute jetzt per E-Mail ein.** In der
  Nutzerverwaltung steht ganz oben „Einladen": Adresse, Name, Abteilung und
  Rolle eintragen, fertig. Der Eingeladene bekommt eine Mail mit einem
  sechsstelligen Code, tippt in der App auf **„Ich habe eine Einladung"** und
  wählt dabei sein eigenes Passwort. Der große Gewinn: So ein Konto kann
  „Passwort vergessen" benutzen — ein Konto vom Zugangszettel nie, weil an die
  interne Adresse `@fw.local` keine Post zugestellt werden kann. Der
  Zugangszettel bleibt für alle, die keine E-Mail-Adresse angeben wollen.
- **Die Einladung entscheidet nicht über Rechte — die Bestätigung tut es.**
  Solange der Code nicht eingelöst ist, hat das Konto keine Abteilung und
  keine Rolle; es sieht also auch nichts. Erst mit dem Einlösen bekommt es
  genau die Rolle in genau der Abteilung, die in der Einladung steht.
- **Offene Einladungen stehen in der Liste** — mit „Erneut senden", falls die
  Mail nicht ankam, und „Zurückziehen", falls sie an die falsche Adresse ging.
  Zurückziehen gibt die Adresse sofort wieder frei.
- **Der Anzeigename kommt aus der Einladung.** Wer als „Max Muster"
  eingeladen wird, heißt danach in der Nutzerliste auch so — und nicht
  `max.muster` nach dem Anfang seiner E-Mail-Adresse.
- **Wer wen einladen darf, folgt der Feuerwehr-Hierarchie:** Der
  Feuerwehrkommandant lädt in jede Abteilung seiner Gesamtwehr ein und kann
  einen zweiten Feuerwehrkommandanten ernennen (der Schutz davor, dass sich
  die Wehr aussperrt). Ein Abteilungskommandant lädt nur in seine eigene
  Abteilung ein und höchstens als Gerätewart. Ein Gerätewart lädt niemanden
  ein.

## [1.16.1] – 2026-08-03

### Behoben

- **In der Web-App auf dem iPhone sind wieder alle Fotos zu sehen.** Gerätefotos,
  Fahrzeugfotos und der neue Kopfbereich blieben dort leer und zeigten nur eine
  graue Fläche — auf Android war alles in Ordnung. Ursache war die Art, wie die
  Web-App Bilder vom Server holte: Sie schickte dabei die Anmeldung nicht mit,
  und der Server gibt Fotos nur an Angemeldete heraus. Das betraf alle zentral
  gespeicherten Fotos, seit es sie gibt.

## [1.16.0] – 2026-08-03

### Neu

- **Eure Gesamtwehr zeigt sich jetzt auf der Startseite.** Ganz oben steht
  ein eigener Kopfbereich: ein Bild vom Gerätehaus oder vom Fuhrpark, der
  Name der Wehr und ein Begrüßungstext — zum Beispiel der nächste
  Übungstermin. Alle Abteilungen der Gesamtwehr sehen dasselbe. Ist nichts
  eingerichtet, bleibt die Startseite wie bisher; es entsteht kein leerer
  Kasten.
- **Eingerichtet wird das vom Feuerwehrkommandanten** unter *Mehr →
  Abteilung & Gesamtwehr → Kopfbereich der Startseite*. Beim Tippen seht ihr
  sofort, wie es später aussieht. Ein Gerätewart sieht den Kopf, ändern kann
  ihn nur der Kommandant — den Gerätebestand pflegt die ganze Wehr, wie sie
  sich zeigt, entscheidet ihre Führung.
- Einmal geladen, steht der Kopfbereich **auch ohne Netz** — wie die
  Gerätefotos.

### Bekannt

- In der **Web-App auf dem iPhone** fehlt im Kopfbereich zurzeit das Bild;
  Überschrift und Text stehen dort normal. Auf Android ist alles zu sehen.
  Die Ursache betrifft alle zentral gespeicherten Fotos und wird getrennt
  behoben.

## [1.15.0] – 2026-08-02

### Neu

- **Geräte lassen sich jetzt aus dem mitgelieferten Katalog anlegen.** Im
  Geräteformular steht über dem Namensfeld „Aus dem Gerätekatalog wählen":
  suchen wie in der Bildbibliothek — über Name, Kurzform und gebräuchliche
  Bezeichnungen —, antippen, fertig. Das Gerät bringt dabei mit, was ihr
  sonst gar nicht eintippen könntet: Kurzform, Symbolbild, typische
  Verwendung und die Lernfragen. Bisher half der Katalog nur, wenn ihr den
  Normnamen zufällig genau getroffen habt.
- **Selbst angelegte Geräte könnt ihr für den Katalog vorschlagen.** Auf der
  Geräteseite unter den drei Punkten oben rechts. Der Vorschlag geht an die
  Entwicklung, damit der Typ in einer der nächsten Versionen für alle
  mitgeliefert wird. Vor dem Absenden seht ihr wörtlich, was übermittelt
  wird: Name, Kurzform, Beschreibung und eure Abteilung — **kein Foto**, und
  der Text erscheint öffentlich.

## [1.14.0] – 2026-08-02

### Neu

- **Der geteilte Gerätebestand ist jetzt bedienbar.** Was ihr an einem Gerät
  ändert — Name, Beschreibung, Lernmaterial, Foto oder Piktogramm — geht
  sofort an die ganze Gesamtwehr; ein neu angelegtes Gerät ebenso. Die
  Meldung nach dem Speichern sagt euch, ob es draußen ist.
- **Ihr seht jetzt, wie weit eine Änderung reicht.** Auf der Geräteseite und
  im Bearbeiten-Formular steht, ob das Gerät zum geteilten Bestand der
  Gesamtwehr gehört — und wenn eine Änderung noch beim nächsten
  Aktualisieren rausgeht, steht auch das dort.
- **Geräte entfernen — mit klarer Ansage.** Unter den drei Punkten oben
  rechts. Benutzt keine andere Abteilung das Gerät, wird es überall
  gelöscht. Hängt es anderswo noch in einem Fach oder an einem Exemplar,
  wird es nur archiviert: Dort bleibt es erhalten, aus dem gemeinsamen
  Katalog verschwindet es. Was bei euch selbst daran hängt, nennt die
  Rückfrage vorher beim Namen.

### Behoben

- **Beim Bearbeiten gingen Angaben verloren, die das Formular gar nicht
  zeigt** — Trainingsfragen, typische Verwendung, technische Daten und die
  Zugehörigkeit zum mitgelieferten Katalog. Wer nur den Namen korrigierte,
  räumte sie mit weg. Sie bleiben jetzt stehen.
- Die Geräteliste hält sich von selbst aktuell: Ein gelöschtes oder neu
  angelegtes Gerät ist sofort verschwunden bzw. da, ohne Umweg.

### Hinweis

Ein Foto, das nur auf eurem Gerät liegt (weil der Upload nicht durchkam),
wird nicht an die anderen Abteilungen verteilt — es wäre dort ein toter
Verweis. Es bleibt vorgemerkt und geht mit, sobald der Upload klappt.

## [1.13.0] – 2026-08-02

### Neu

- **Gerätetypen gehören jetzt der ganzen Wehr.** Was ein C-Strahlrohr *ist* —
  Name, Kurzform, Foto, Piktogramm — pflegt ihr ab sofort gemeinsam: Legt
  Grombach einen Typ an, steht er auch in Bad Rappenau Stadt zur Verfügung,
  mit demselben Bild. Die Geräte selbst, ihre Seriennummern und die
  Prüfhistorie bleiben unverändert bei eurer Abteilung.
- Damit sich beim Umschalten nichts doppelt: Ein geteilter Typ hängt sich an
  das Gerät an, das ihr schon habt, statt daneben ein zweites anzulegen.

### Hinweis

Die App holt den geteilten Bestand ab dieser Version im Hintergrund mit —
beim Start und bei **Jetzt aktualisieren**. Die Oberfläche dazu (Typen
suchen, ändern, aus dem Bestand nehmen) kommt in der nächsten Version.

## [1.12.0] – 2026-08-02

### Neu

- **Die gewählte Abteilung steht jetzt oben rechts in der Leiste** — auf der
  Startseite, beim Lernen, bei Fahrzeugen und Geräten, unter „Mehr" und in
  den Einstellungen. Sie nennt die Abteilung beim Namen, und ein Tipp darauf
  öffnet die Auswahl: Kein Weg mehr über die Einstellungen, wenn du nur
  kurz in die Nachbar-Abteilung schauen willst.
- **Auf einen Blick, ob du daheim bist.** In deiner eigenen Abteilung bleibt
  die Anzeige zurückhaltend; sobald du eine Schwester-Abteilung ansiehst,
  ist sie farbig abgesetzt und trägt ein Auge statt des Hauses.

### Geändert

- **Die Abteilungswahl sagt jetzt, was du wo darfst.** Bisher stand an jeder
  fremden Abteilung pauschal „nur lesen" — seit den Rollen je Abteilung
  (1.11.0) stimmte das nicht mehr: Wer in einer zweiten Abteilung Gerätewart
  ist oder die Gesamtwehr führt, darf dort sehr wohl arbeiten. Die Auswahl
  nennt deshalb bei jeder Abteilung deine Rolle.
- Die schon angezeigte Abteilung noch einmal auszuwählen lädt den Bestand
  nicht mehr neu.

## [1.11.0] – 2026-08-02

### Neu

- **Rollen heißen jetzt wie bei der Feuerwehr — und gelten je Abteilung.**
  Aus Admin, Gerätewart und Mitglied werden Abteilungskommandant,
  Gerätewart und Truppführer/Truppmann. Dieselbe Person kann in mehreren
  Abteilungen (auch unterschiedliche) Rollen haben — etwa ein Gerätewart,
  der zwei Abteilungen betreut. In der Nutzerverwaltung bündelt der neue
  Dialog **„Rollen & Abteilungen"** alles an einem Ort.
- **Der Feuerwehrkommandant ist eine eigene Stellung.** Wer die Gesamtwehr
  gründet, ist ihr erster Kommandant; weitere lassen sich in der
  Nutzerverwaltung ernennen (und entlassen). Der Kommandant arbeitet in
  allen Abteilungen seiner Gesamtwehr, legt Abteilungen an und entscheidet
  über Anschluss-Anfragen — ein Abteilungskommandant nur in seiner.
- **Schreibrechte folgen der gewählten Abteilung.** Wer in der gerade
  angezeigten Abteilung keine Schreibrolle hat, sieht sie lesend — auch
  als Kommandant einer anderen Gesamtwehr. Die Einstellungen zeigen die
  Rolle jetzt für die aktuelle Sicht an.

Das ist Stufe 1 des Nutzerkonzepts (docs/NUTZERKONZEPT.md); ältere
App-Versionen laufen unverändert weiter, bis die Mindestversion angehoben
wird.

## [1.10.0] – 2026-08-02

### Neu

- **Geräte lassen sich endlich von Hand in ein Fach legen.** Im Fahrzeug
  öffnet jedes Beladefach jetzt „Gerät zuweisen": suchen, antippen, drin —
  das funktioniert in der Fächerliste und in der Schnittdarstellung. Über
  das Menü an jedem Gerät lassen sich Menge ändern und die Zuweisung wieder
  entfernen. Bisher konnten Geräte nur per Import oder Vorlage in ein Fach
  gelangen.
- **Neue Geräte entstehen direkt im Fach.** Ist das Gerät noch gar nicht
  erfasst, führt „… neu anlegen" aus derselben Auswahl ins Geräte-Formular —
  der eingetippte Suchbegriff steht schon als Name drin, und nach dem
  Speichern liegt das Gerät im offenen Fach. So bildet man ein Fahrzeug
  Raum für Raum ab, ohne zwischendurch in die Geräteverwaltung zu wechseln.
- **Das Symbolbild kommt beim Tippen von allein.** Passt der eingegebene
  Name zu einem Normgerät (auch über gängige Zweitnamen wie „Pylone" oder
  „B-Schlauch"), setzt die App dessen Piktogramm automatisch — sichtbar
  gekennzeichnet als *Symbolbild, kein verifiziertes Foto*. Ein eigenes
  Foto ersetzt es jederzeit und wird nie überschrieben.

### Behoben

- **„Mit Normbeladung" legt die Geräte jetzt auch wirklich an.** Auf
  Geräten, die schon einmal den zentralen Datenbestand geladen hatten,
  entstand aus einer Vorlage ein Fahrzeug ganz ohne Geräte — der
  mitgelieferte Katalog fehlte dort still. Die Vorlage legt fehlende
  Katalog-Geräte jetzt selbst nach, und falls doch einmal Positionen
  übersprungen werden, sagt die App das offen dazu.

## [1.9.1] – 2026-08-01

### Geändert

- **Die Zwei-Faktor-Anmeldung bleibt freiwillig — auch für Admins.** Die
  mit v1.9.0 angekündigte Pflicht ab dem 1. September ist gestrichen; die
  Einrichtung wird Admin-Konten weiterhin empfohlen. Wer einen zweiten
  Faktor eingerichtet hat, meldet sich damit unverändert auch an.

### Behoben

- Die Kachel *Einstellungen → Zwei-Faktor-Anmeldung* führt jetzt wirklich
  zur Einrichtung — vorher sprang die App zurück auf die Startseite.

## [1.9.0] – 2026-08-01

### Neu

- **Zwei-Faktor-Anmeldung.** Unter *Einstellungen → Zwei-Faktor-Anmeldung*
  lässt sich das Konto zusätzlich mit einer Authenticator-App absichern:
  Beim Anmelden fragt die App dann nach einem sechsstelligen Code, der alle
  30 Sekunden wechselt. Ein abgeschautes Passwort allein reicht damit nicht
  mehr.
- **Für Admin-Konten wird das ab dem 1. September Pflicht.** Bis dahin ist
  es eine Empfehlung; danach führt der Weg beim Anmelden über die
  Einrichtung. Gerätewarte und Mitglieder sind nicht betroffen.
- Einrichten ohne QR-Code-Scannerei: Ein Knopf öffnet die Authenticator-App
  direkt, und wer sie auf einem anderen Gerät hat, tippt den Schlüssel ab —
  er steht in gut lesbaren Viererblöcken da und lässt sich kopieren.
- **Telefon verloren?** Ein Admin setzt den zweiten Faktor in der
  Nutzerverwaltung zurück (Kontomenü → „Zwei-Faktor zurücksetzen"); danach
  meldet sich die Person wieder allein mit dem Passwort an und richtet ihn
  neu ein.

## [1.8.0] – 2026-08-01

### Neu

- **Passwort vergessen — ohne den Umweg über den Gerätewart.** Auf dem
  Anmeldebildschirm führt „Passwort vergessen?" zu einer E-Mail mit einem
  sechsstelligen Code. Den tippt man in der App ein und vergibt direkt sein
  neues Passwort. Der Code funktioniert auch dann, wenn die Mail am PC
  gelesen und die App am Handy bedient wird — genau daran scheitern die
  üblichen Links.
- Das geht für Konten mit **hinterlegter E-Mail-Adresse**, also für Admins
  und Gerätewarte. Wer sich mit einem Zugangszettel anmeldet, wendet sich
  weiterhin an den Gerätewart — dort ändert sich nichts.
- **E-Mail-Adressen in der Nutzerverwaltung.** Über das Menü einer
  Kontozeile lässt sich eine Adresse hinterlegen oder ändern, und es gibt
  einen Knopf „Passwort-Mail senden". Damit richtet man jemanden ein, ohne
  je ein Passwort auszusprechen: Adresse eintragen, Mail schicken, die
  Person setzt sich selbst eines.
- **Achtung dabei:** Wer eine E-Mail-Adresse bekommt, meldet sich ab dann
  mit dieser Adresse an — nicht mehr mit dem Nutzernamen. Die App weist im
  Dialog darauf hin. Der Nutzername bleibt als Anzeigename in der Liste
  stehen.

## [1.7.0] – 2026-08-01

### Geändert

- **Die App beginnt jetzt mit der Anmeldung.** Wer mit der Abteilung
  verbunden ist, landet beim Start auf einem eigenen Anmeldebildschirm
  statt in der App. Bisher kam man auch ohne Anmeldung überall hin — nur
  eben ohne Daten, weil ohne Anmeldung nichts vom Server geladen wird. Das
  sah aus wie eine leere App und war in Wahrheit eine unangemeldete.
- **Wichtig für den Umstieg:** Wer die Cloud-Synchronisation eingeschaltet,
  sich aber noch nie angemeldet hat, braucht ab jetzt seinen Zugangszettel.
  Frisch installierte Geräte sind nicht betroffen — sie starten ohne
  Synchronisation und bleiben ohne Anmeldung nutzbar.
- Der **Passwortwechsel beim ersten Anmelden** ist kein Dialog mehr,
  sondern eine eigene Seite. Er lässt sich nicht mehr wegtippen; der
  einzige andere Weg ist Abmelden.

### Neu

- **Auge im Passwortfeld:** Das getippte Passwort lässt sich sichtbar
  machen — die zuverlässigere Kontrolle als blindes Tippen.
- **Servereinstellungen ohne Anmeldung erreichbar.** Vom Anmeldebildschirm
  führt ein Knopf zu Adresse und Schlüssel des Servers. Ohne diesen Weg
  säße man mit einer falschen Serveradresse fest: anmelden ginge nicht,
  und die Einstellungen lägen hinter der Anmeldung.
- Der Anmeldebildschirm zeigt **vor** dem Versuch, ob der Server überhaupt
  antwortet — ein Netzproblem sieht damit nicht mehr aus wie ein falsches
  Passwort.

## [1.6.3] – 2026-08-01

### Neu

- **Die Abteilung gehört jetzt zur Nutzerverwaltung.** In der Kontoliste
  steht bei jedem Konto, zu welcher Abteilung es gehört. Über das Menü der
  Kontozeile lässt sich das ändern, und beim Anlegen eines Kontos gibt es
  ein Feld dafür — vorbelegt mit der eigenen Abteilung. Damit ist der
  letzte Handgriff aus dem Abteilungs-Aufbau in der App angekommen; vorher
  musste dafür jemand an den Server.
- Wählbar sind ausschließlich Abteilungen der **eigenen Gesamtwehr**. Der
  Server prüft das noch einmal selbst und lehnt alles andere ab.

## [1.6.2] – 2026-08-01

### Behoben

- **Lange Absturzberichte ließen sich nicht melden.** Der Server nimmt
  Meldungen bis 2000 Zeichen an; Absturzberichte mit Protokoll-Anhang sind
  länger, und das Senden scheiterte mit dem irreführenden Hinweis auf die
  Internetverbindung. Die App kürzt jetzt vor dem Senden sichtbar auf das
  Limit — der wichtige Anfang (Fehler und Absturzstelle) bleibt immer
  erhalten.

## [1.6.1] – 2026-08-01

### Behoben

- **„Gesamtwehr gründen" und „Abteilung anlegen" taten nichts:** Der
  Anlegen-Knopf im Namens-Dialog schloss den Dialog über die falsche
  Navigationsebene — sichtbar passierte gar nichts. Betroffen war auch das
  Bestätigen und Ablehnen von Anschluss-Anfragen. Alle drei Dialoge
  funktionieren jetzt; ein automatischer Test bildet die echte
  Navigationsstruktur der App nach, damit genau das nicht wieder
  unbemerkt durchrutscht.

## [1.6.0] – 2026-08-01

### Neu

- **Gesamtwehr und Verbindungen** (dritter Schritt zu #57): Unter **Mehr →
  Abteilung & Gesamtwehr** siehst du, zu welcher Abteilung du gehörst und ob
  sie einer Gesamtwehr angeschlossen ist. Ein Admin kann die Gesamtwehr
  **gründen** und **weitere Abteilungen anlegen** — beides direkt in der App,
  ohne dass jemand am Server arbeiten muss.
- **Anschluss beantragen und freigeben:** Eine eigenständige Abteilung kann
  um Anschluss an eine bestehende Gesamtwehr bitten; entscheiden tut das der
  Admin dieser Gesamtwehr. Wer fragt, gibt sich nicht selbst frei. Nach der
  Freigabe sehen die verbundenen Abteilungen den Bestand der jeweils anderen
  — **lesend**, bearbeiten darf weiterhin jede nur ihren eigenen.
- Eine neu angeschlossene Abteilung ist mit der Freigabe zugleich
  **freigeschaltet** und darf veröffentlichen. Bis dahin arbeitet sie ganz
  normal lokal weiter; nur das Veröffentlichen wartet.

## [1.5.6] – 2026-08-01

### Neu

- **Abteilungswahl** (zweiter Schritt zu #57): Wer zu einer Gesamtwehr
  gehört, sieht in den Einstellungen seine Abteilung und kann in die
  Schwester-Abteilungen wechseln — **lesend**, zum Lernen an deren
  Fahrzeugen. Bearbeiten und Veröffentlichen gibt es nur in der eigenen.
  Jede Abteilung hat ihren eigenen lokalen Bestand; beim Zurückwechseln
  ist alles unverändert da, auch offline.

## [1.5.5] – 2026-08-01

### Unter der Haube

- **Vorbereitung für Abteilungen** (erster Schritt zu #57): Der Server kennt
  jetzt Abteilungen als eigene Datenbestände, und die App synchronisiert
  gezielt den Bestand ihrer Abteilung. Sichtbar ändert sich noch nichts —
  es existiert weiterhin genau eine Abteilung, und die App arbeitet mit
  älteren Servern unverändert zusammen. Die Abteilungswahl und die
  Gesamtwehr folgen in den nächsten Versionen.

## [1.5.4] – 2026-08-01

### Neu

- **Drei wählbare Farbkonzepte** unter Einstellungen → Darstellung
  (Issue #58): **Florian** (Feuerrot auf ruhigem Grund, der Ton des
  App-Icons), **Blaulicht** (Signalblau mit rotem Zweitakzent — die
  Farbpaarung des Einsatzfahrzeugs) und **Glut** (Warnorange wie
  Einsatzjacke und Helm). Dazu **Eigenes Farbthema** mit freier Farbwahl.
  Jedes Konzept unterstützt Hell und Dunkel; welcher Modus gilt, steuert
  wie bisher der Design-Schalter (Standard: folgt dem System).
- Auf einer verbundenen Installation legt die **Verwaltung** das Farbthema
  fest; im reinen Lokalbetrieb wählt ihr frei.

### Verbessert

- **Modernere Formensprache:** randlose Karten mit großen Radien statt
  umrandeter Kästen, Symbole in getönten Kacheln, ein Handlungsaufruf mit
  Farbverlauf und die aktualisierten Material-Fortschrittsbalken mit
  abgerundeten Enden.
- **Die Farben sitzen jetzt, wo sie hingehören:** Der Handlungsaufruf auf
  der Startseite, die Navigationsleiste und die Fortschrittsbalken tragen
  die kräftige Konzeptfarbe; Flächen und Karten bleiben ruhig. Vorher
  wirkte die App durch die vielen Pastellflächen blasser als gedacht.
- Mehrere Stellen repariert, an denen Schrift auf getönten Flächen die
  falsche Farbe erbte und je nach Thema schwer lesbar werden konnte
  (Startseiten-Banner, „Weiterlernen", Karteikarten, Fahrzeug-Formular).
  Ein automatischer Test prüft jetzt jede Farbkombination aller Konzepte
  gegen die WCAG-Lesbarkeitsschwelle.

## [1.5.3] – 2026-07-31

### Neu

- **Fahrzeuge lassen sich aus einer Vorlage anlegen.** Beim Anlegen gibt es
  jetzt Vorlagen für LF 10, LF 20, HLF 20, TSF-W, DLK 23/12, RW, GW-L, MTW und
  ELW 1: Die Geräteräume (G1–G6, Heck, Dach) entstehen mit einem Griff statt
  von Hand.
- Für **LF 20 und HLF 20** lässt sich zusätzlich die Normbeladung übernehmen —
  63 bzw. 73 Positionen. ⚠️ Die Liste ist **ungeprüft** und stammt aus einer
  öffentlichen Beladeliste einer Feuerwehrschule; sie gehört durchgegangen.
  Weil die Norm nur vorschreibt, *was* an Bord ist und nicht, in welchem
  Geräteraum es liegt, landen die Positionen gesammelt in einem eigenen Fach.
  Von dort verteilt ihr sie auf eure Räume — genau so, wie sie bei euch
  wirklich liegen.
- Für die übrigen Fahrzeugtypen liegt keine belegbare Liste vor; dort legt die
  Vorlage nur die Geräteräume an. Beladung kommt weiterhin über den
  Import-Assistenten oder von Hand dazu.

## [1.5.2] – 2026-07-31

### Behoben

- **Absturzberichte gingen ausgerechnet bei den schlimmsten Abstürzen
  verloren.** Der Bericht wurde nebenher geschrieben; stürzte die App hart ab,
  war er weg. Jetzt wird er sofort gesichert, bevor irgendetwas anderes
  passiert.

### Geändert

- Ein Absturzbericht enthält jetzt auch Android-Version, Spracheinstellung und
  die letzten Protokollzeilen davor. Ohne diese Vorgeschichte lässt sich ein
  Fehler oft gar nicht nachvollziehen.
- Stürzt dieselbe Sache mehrfach ab, erscheint sie nur noch **einmal** statt
  als lange Liste gleicher Meldungen.
- Der Hinweis im Melde-Dialog sagt jetzt genau, was im Bericht steht — vorher
  stand dort „keine Gerätedaten", obwohl inzwischen die Android-Version
  mitgeschickt wird.

## [1.5.1] – 2026-07-31

### Geändert

- **Bilder auswählen ist deutlich besser geworden.** Beim Fahrzeug- und
  Gerätebild lässt sich jetzt wählen, ob man ein Foto aufnimmt oder eins aus
  der Galerie holt. Danach öffnet sich ein Editor: Der Rahmen steht fest und
  ist der spätere Bildausschnitt, das Bild bewegt man darin — mit zwei Fingern
  zoomen und drehen, mit einem verschieben. Dazu ein Knopf für 90°-Sprünge und
  einer zum Zurücksetzen, mit großen Schaltflächen, die sich auch mit Handschuh
  treffen lassen.
- Bilder werden automatisch auf eine sinnvolle Größe gerechnet. Die vorher
  vorgeschaltete Frage nach der Bildgröße entfällt damit.

## [1.5.0] – 2026-07-31

### Neu

- Stürzt die App ab, bietet sie beim nächsten Start an, das Problem zu melden —
  mit den technischen Angaben, die zur Behebung nötig sind. Vorher blieben
  solche Fehler unbemerkt, wenn niemand von sich aus schrieb. Der Bericht
  enthält keine Gerätedaten und geht nur auf ausdrückliche Bestätigung raus;
  alternativ lässt er sich kopieren.

### Geändert

- Ist eine App-Version zu alt, lehnt der Server das **Veröffentlichen** ab und
  sagt das mit klarem Hinweis. Das schützt den gemeinsamen Datenbestand davor,
  von einem alten Stand unvollständig überschrieben zu werden. Wichtig: Nur das
  Veröffentlichen ist betroffen — die App bleibt vollständig nutzbar, lokale
  Daten bleiben erhalten, und Aktualisieren funktioniert weiter.

## [1.4.9] – 2026-07-31

### Neu

- **Was ist neu?** unter Einstellungen → App-Information: die Änderungen aller
  bisherigen Versionen, die installierte Version ist markiert. Funktioniert
  ohne Netz.

## [1.4.8] – 2026-07-31

### Geändert

- Unterbau auf Flutter 3.44.8 gehoben und alle Bibliotheken nachgezogen. Für
  die Bedienung ändert sich nichts; die App läuft auf aktuellerer Technik und
  bleibt damit sicherheitstechnisch versorgt.

### Behoben

- Beim Sortieren der Geräteräume per Drag & Drop konnte ein Fach eine Position
  zu weit rutschen.

## [1.4.7] – 2026-07-23

### Geändert

- Sammel-Aktualisierung aller verwendeten Bibliotheken.

## [1.4.6] – 2026-07-20

### Behoben

- Geräte einer Serie werden wieder mit ihrem eigenen Symbol angezeigt.
- Ein seltener Absturz direkt beim App-Start ist behoben.

## [1.4.5] – 2026-07-20

### Neu

- Die Lizenzen aller mitgelieferten Fremdbibliotheken sind jetzt in der App
  einsehbar (Einstellungen → Open-Source-Lizenzen).

### Behoben

- Die Anmeldesitzung wandert nicht mehr in das Google-Cloud-Backup. Nach einem
  Gerätewechsel muss man sich einmal neu anmelden — das ist gewollt.

## [1.4.4] – 2026-07-20

### Behoben

- Release-Builds schreiben wieder Protokolleinträge. Ohne sie war jede
  Fehlersuche im Feld blind.

## [1.4.3] – 2026-07-20

### Behoben

- Links öffnen sich unter Android 11 und neuer wieder zuverlässig im Browser.

## [1.4.2] – 2026-07-19

### Geändert

- Aufräumarbeiten unter der Haube: Zugriffsschutz auch für direkt aufgerufene
  Adressen (wichtig in der Web-Version) und ein zentrales Protokoll.

## [1.4.1] – 2026-07-19

### Neu

- Das Design folgt jetzt der Systemeinstellung für Hell/Dunkel und lässt sich
  weiterhin von Hand überschreiben.

## [1.4.0] – 2026-07-19

### Neu

- Rückmeldungen lassen sich direkt aus der App senden.
- Die App meldet neue Versionen selbst und kann sie auf Wunsch gleich
  installieren.

## [1.3.1] – 2026-07-18

### Behoben

- Der Serverabgleich funktioniert wieder auf echten Geräten (der fertigen
  App fehlte die Berechtigung für Internetzugriff).

## [1.3.0] – 2026-07-18

### Neu

- Anmeldung per Benutzername statt E-Mail.
- Ein Initialpasswort muss bei der ersten Anmeldung gewechselt werden.
- Nutzerverwaltung für Administratoren.

## [1.2.1] – 2026-07-18

### Neu

- Der Server ist öffentlich über HTTPS erreichbar, der Abgleich funktioniert
  damit auch außerhalb des Feuerwehr-WLANs.

## [1.2.0] – 2026-07-17

### Neu

- Rollenmodell mit eigener Gerätewart-Rolle.

## [1.1.1] – 2026-07-17

### Neu

- FWApp läuft als Web-App im Browser — die Zwischenlösung für iPhones.
- Der Serverstatus ist schon vor der Anmeldung sichtbar.

## [1.1.0] – 2026-07-16

### Neu

- Symbolbilder für alle Normgeräte samt Bildbrowser und Suche.
- Demo-Datenbestand (HLF 20) und Beispieldateien für den Import.

### Geändert

- Die App steht unter der MIT-Lizenz.

## [1.0.0] – 2026-07-15

### Neu

- Erste Ausgabe: Fahrzeuge, Geräteräume, Beladepläne, Lernspiele und
  Serverabgleich.

[1.5.6]: https://github.com/MacBuchi/FWApp/compare/v1.5.5...v1.5.6
[1.5.5]: https://github.com/MacBuchi/FWApp/compare/v1.5.4...v1.5.5
[1.5.4]: https://github.com/MacBuchi/FWApp/compare/v1.5.3...v1.5.4
[1.5.3]: https://github.com/MacBuchi/FWApp/compare/v1.5.2...v1.5.3
[1.5.2]: https://github.com/MacBuchi/FWApp/compare/v1.5.1...v1.5.2
[1.5.1]: https://github.com/MacBuchi/FWApp/compare/v1.5.0...v1.5.1
[1.5.0]: https://github.com/MacBuchi/FWApp/compare/v1.4.9...v1.5.0
[1.4.9]: https://github.com/MacBuchi/FWApp/compare/v1.4.8...v1.4.9
[1.4.8]: https://github.com/MacBuchi/FWApp/compare/v1.4.7...v1.4.8
[1.4.7]: https://github.com/MacBuchi/FWApp/compare/v1.4.6...v1.4.7
[1.4.6]: https://github.com/MacBuchi/FWApp/compare/v1.4.5...v1.4.6
[1.4.5]: https://github.com/MacBuchi/FWApp/compare/v1.4.4...v1.4.5
[1.4.4]: https://github.com/MacBuchi/FWApp/compare/v1.4.3...v1.4.4
[1.4.3]: https://github.com/MacBuchi/FWApp/compare/v1.4.2...v1.4.3
[1.4.2]: https://github.com/MacBuchi/FWApp/compare/v1.4.1...v1.4.2
[1.4.1]: https://github.com/MacBuchi/FWApp/compare/v1.4.0...v1.4.1
[1.4.0]: https://github.com/MacBuchi/FWApp/compare/v1.3.1...v1.4.0
[1.3.1]: https://github.com/MacBuchi/FWApp/compare/v1.3.0...v1.3.1
[1.3.0]: https://github.com/MacBuchi/FWApp/compare/v1.2.1...v1.3.0
[1.2.1]: https://github.com/MacBuchi/FWApp/compare/v1.2.0...v1.2.1
[1.2.0]: https://github.com/MacBuchi/FWApp/compare/v1.1.1...v1.2.0
[1.1.1]: https://github.com/MacBuchi/FWApp/compare/v1.1.0...v1.1.1
[1.1.0]: https://github.com/MacBuchi/FWApp/compare/v1.0.0...v1.1.0
[1.0.0]: https://github.com/MacBuchi/FWApp/releases/tag/v1.0.0
